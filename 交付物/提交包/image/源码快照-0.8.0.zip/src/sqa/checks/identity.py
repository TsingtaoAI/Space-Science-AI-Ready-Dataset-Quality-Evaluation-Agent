"""事件身份标识：源事件目录中的事件都带正式身份标识，格式与同批不符的事件疑似虚构（虚标）。"""
from __future__ import annotations

import re
from collections import Counter

from ..model import Location, defect, merge, not_applicable, ok
from ..registry import check
from ._util import events, events_ptr

_NULLISH = {"", "none", "null", "nan"}


def shape(v) -> str | None:
    """取值的格式型：字母记 a、数字记 9；空值与字符串 None/null 记为 None。"""
    if v is None or (isinstance(v, str) and v.strip().lower() in _NULLISH):
        return None
    return re.sub(r"[A-Za-z]", "a", re.sub(r"\d", "9", str(v)))


def _dominant(ctx, keys: tuple, tol: dict) -> dict[str, str] | None:
    """各身份字段的主流格式型；同批事件太少或没有主流格式时返回 None（不适用）。"""
    cache = ctx.cache.setdefault("identity_dominant", {})
    if keys in cache:
        return cache[keys]
    counts = {k: Counter() for k in keys}
    n = 0
    for rec in ctx.records:
        if ctx.profile(rec) is None or not ctx.profile_spec(rec).get("events"):
            continue
        for e in events(ctx, rec):
            n += 1
            for k in keys:
                counts[k][shape(e.get(k))] += 1
    dom = {}
    if n >= tol["min_elements"]:
        for k, c in counts.items():
            s, m = c.most_common(1)[0]
            if s is not None and m / n >= tol["dominant_share"]:
                dom[k] = s
    cache[keys] = dom or None
    return cache[keys]


@check("M03")
def identity_format(ctx, rec):
    keys = tuple(ctx.profile_spec(rec)["events"].get("identity_keys", ()))
    if not keys:
        return not_applicable(rec.key, "该标注族未声明事件身份字段")
    tol = ctx.spec.check("M03").tolerance
    dom = _dominant(ctx, keys, tol)
    if not dom:
        return not_applicable(rec.key, f"同批事件少于 {tol['min_elements']} 个或身份字段没有占比 ≥ {tol['dominant_share']} 的主流格式")
    outs = []
    for i, e in enumerate(events(ctx, rec)):
        bad = {k: e.get(k) for k, s in dom.items() if shape(e.get(k)) != s}
        if bad:
            outs.append(defect(rec.key, Location(rec.key, pointer=events_ptr(ctx, rec, i)),
                               "事件身份标识缺失或格式与同批不符（疑似虚构标注）",
                               identity=bad, dominant_format=dom))
    return merge(rec.key, outs) if outs else ok(rec.key)
